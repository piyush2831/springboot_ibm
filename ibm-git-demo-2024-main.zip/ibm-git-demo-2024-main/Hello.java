public class Hello {
	
	public static void main(String[] args) {
		
		System.out.println("Hello world!");
		System.out.println("Hello world! 2");
	}
}



/*

For newly created repository - 
------------------------------
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/vamandeshmukh/ibm-git-demo-2024.git
git push -u origin main

For subsequent changes in the code 
----------------------------------

git add . 
git commit -m "some commit message"
git push 


*/

